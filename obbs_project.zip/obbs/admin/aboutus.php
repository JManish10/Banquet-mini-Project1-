<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['odmsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {
$odmsaid=$_SESSION['odmsaid'];
 $pagetitle=$_POST['pagetitle'];
$pagedes=$_POST['pagedes'];
$sql="update tblpage set PageTitle=:pagetitle,PageDescription=:pagedes where  PageType='aboutus'";
$query=$dbh->prepare($sql);
$query->bindParam(':pagetitle',$pagetitle,PDO::PARAM_STR);
$query->bindParam(':pagedes',$pagedes,PDO::PARAM_STR);

$query->execute();
echo '<script>alert("About us has been updated")</script>';


  }
  ?>
<!doctype html>
 <html lang="en" class="no-focus">
    <head>
 <title> Update About Us</title>
<link rel="stylesheet" id="css-main" href="assets/css/codebase.min.css">

</head>
    <body>
        <div id="page-container" class="sidebar-o sidebar-inverse side-scroll page-header-fixed main-content-narrow">
     

             <?php include_once('includes/sidebar.php');?>

          
           
            <main id="main-container">
         
                <div class="content">
                
                    <h2 >Update About Us</h2>
                    <div >
                        <div >
                          
                            <div >
                            
                                <div>
                                   
                                    <form method="post">
                                <?php

$sql="SELECT * from  tblpage where PageType='aboutus'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>        
                                        <div class="form-group row">
                                            <label class="col-12" for="register1-email">Page Title:</label>
                                            <div class="col-12">
                                                 <input type="text" size="100" value="<?php  echo $row->PageTitle;?>" required='true'>
                                            </div>
                                        </div>
                                        <div >
                                            <label>Page Description:</label>
                                            <div class="col-12">
                                                 <textarea type="text" rows ="10" cols='100' required='true'><?php  echo $row->PageDescription;?></textarea>
                                            </div>
                                        </div>
                                        <?php $cnt=$cnt+1;}} ?>
                                        <div >
                                            <div >
                                                <button type="submit" style="color:green" name="submit">
                                                    <i class="fa fa-plus mr-5"></i> Update
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                           
                        </div>
                        
                       </div>
                </div>
               
            </main>
           

          
        </div>
      
    </body>
</html>
<?php }  ?>