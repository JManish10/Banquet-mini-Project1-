<?php 
$con=mysqli_connect('localhost','manish','35'); 
$dbname = mysqli_select_db($con,"obbs"); 
if(isset($_POST['submit'])) 
{ 
    
	$sername=$_POST['sername'];
$serdes=$_POST['serdes'];
$serprice=$_POST['serprice'];
$image = $_FILES['photo']['name'];
$image_tmp = $_FILES['photo']['tmp_file'];
	$file_seperate = explode(".",$image);
	$file_extension = strtolower(end($file_seperate));
	$extension = array("jpg","jpeg","png","gif");
	if(in_array($file_extension,$extension)) {
		$upload_image = "images/".$image;
		move_uploaded_file($image_tmp,$upload_image);
		$sql="insert into tblservice(ServiceName,SerDes,ServicePrice,image)values('$sername','$serdes','$serprice','$image')";
		$result = mysqli_query($con,$sql); 
	if($result) {
		 echo "inserted succesfully";
	}
	else {
		 die( mysqli_error($con));
		 }
}
}
?>